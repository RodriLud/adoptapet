package com.proyecto.adoptapet.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.proyecto.adoptapet.model.Adoptante;
import com.proyecto.adoptapet.model.Usuario;
import com.proyecto.adoptapet.repository.AdoptanteRepository;
import com.proyecto.adoptapet.repository.UsuarioRepository;

@Service
public class UsuarioService implements UserDetailsService {

	@Autowired
	private UsuarioRepository repo;

	@Autowired
	private AdoptanteRepository adoptanteRepo;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Usuario usuario = repo.findByUsername(username)
				.orElseThrow(() -> new UsernameNotFoundException("Usuario no encontrado"));

		return User.builder()
				.username(usuario.getUsername())
				.password(usuario.getPassword())
				.disabled(Boolean.FALSE.equals(usuario.getActivo()))
				.roles(usuario.getRol().replace("ROLE_", ""))
				.build();
	}

	public Usuario findByUsername(String username) {
		return repo.findByUsername(username).orElse(null);
	}

	public Adoptante saveAdoptante(Adoptante adoptante) {
		return adoptanteRepo.save(adoptante);
	}

	public Boolean existsAdoptanteEmail(String email) {
		return email != null && adoptanteRepo.existsByEmail(email);
	}

	public Boolean existsAdoptanteDni(String dni) {
		return dni != null && adoptanteRepo.existsByDni(dni);
	}
}
