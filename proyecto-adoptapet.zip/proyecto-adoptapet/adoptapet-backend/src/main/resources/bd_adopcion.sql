DROP DATABASE IF EXISTS bd_adopcion;
CREATE DATABASE bd_adopcion;
USE bd_adopcion;

CREATE TABLE usuario (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    rol VARCHAR(30) NOT NULL DEFAULT 'ROLE_ADOPTANTE',
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT chk_rol_valido CHECK (rol IN ('ROLE_ADMIN', 'ROLE_TRABAJADOR', 'ROLE_ADOPTANTE'))
);

CREATE TABLE trabajador (
    id_usuario INT PRIMARY KEY,
    nom_trabajador VARCHAR(100) NOT NULL,
    ape_trabajador VARCHAR(100) NOT NULL,
    dni CHAR(8) UNIQUE NOT NULL,
    fec_nacimiento DATE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    telefono CHAR(9) NOT NULL,
    FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario) ON DELETE CASCADE
);

CREATE TABLE adoptante (
    id_usuario INT PRIMARY KEY,
    nom_adoptante VARCHAR(100) NOT NULL,
    ape_adoptante VARCHAR(100) NOT NULL,
    fec_nacimiento DATE NOT NULL,
    dni CHAR(8) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    telefono CHAR(9) NOT NULL,
    direccion VARCHAR(150),
    FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario) ON DELETE CASCADE
);

CREATE TABLE mascota (
    id_mascota INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    especie VARCHAR(20) NOT NULL,
    raza VARCHAR(50) NOT NULL,
    sexo VARCHAR(20) NOT NULL DEFAULT 'MACHO',
    edad_anios INT DEFAULT 0,
    edad_meses INT DEFAULT 0,
    estado_salud VARCHAR(50) NOT NULL,
    estado_adopcion VARCHAR(20) DEFAULT 'DISPONIBLE',
    estado_esterilizacion VARCHAR(30) NOT NULL DEFAULT 'PENDIENTE',
    observaciones VARCHAR(500),
    ruta_imagen VARCHAR(255),
    version BIGINT DEFAULT 0,
    CONSTRAINT chk_edad_anios CHECK (edad_anios >= 0),
    CONSTRAINT chk_edad_meses CHECK (edad_meses >= 0 AND edad_meses < 12),
    CONSTRAINT chk_mascota_sexo CHECK (sexo IN ('MACHO', 'HEMBRA')),
    CONSTRAINT chk_mascota_salud CHECK (estado_salud IN ('SIN NOVEDADES', 'EN TRATAMIENTO', 'CRITICO')),
    CONSTRAINT chk_mascota_adopcion CHECK (estado_adopcion IN ('DISPONIBLE', 'ADOPTADO', 'RESERVADO', 'INACTIVO')),
    CONSTRAINT chk_mascota_esterilizacion CHECK (estado_esterilizacion IN ('ESTERILIZADO', 'NO ESTERILIZADO', 'PENDIENTE', 'NO APLICA'))
);

CREATE TABLE solicitud (
    id_solicitud INT AUTO_INCREMENT PRIMARY KEY,
    fecha_registro DATE DEFAULT (CURRENT_DATE),
    id_adoptante INT NOT NULL,
    id_mascota INT NOT NULL,
    id_trabajador INT,
    comentario TEXT,
    ruta_pdf_acta VARCHAR(255),
    motivo_adopcion TEXT,
    tipo_vivienda VARCHAR(100),
    experiencia_mascotas TEXT,
    otras_mascotas TEXT,
    cantidad_personas_hogar INT,
    comentarios_adicionales TEXT,
    ruta_dni VARCHAR(255),
    ruta_domicilio VARCHAR(255),
    ruta_acta_firmada VARCHAR(255),
    cantidad_reprogramaciones INT NOT NULL DEFAULT 0,
    motivo_contingencia TEXT,
    fecha_cierre_contingencia DATETIME,
    estado_solicitud VARCHAR(20) DEFAULT 'PENDIENTE',
    motivo_rechazo TEXT,
    CONSTRAINT chk_solicitud_estado CHECK (estado_solicitud IN ('PENDIENTE', 'APROBADA', 'NO_ASISTIO', 'RECHAZADA', 'FINALIZADA', 'CANCELADA')),
    CONSTRAINT chk_personas_hogar CHECK (cantidad_personas_hogar IS NULL OR cantidad_personas_hogar >= 0),
    FOREIGN KEY (id_adoptante) REFERENCES adoptante(id_usuario),
    FOREIGN KEY (id_mascota) REFERENCES mascota(id_mascota),
    FOREIGN KEY (id_trabajador) REFERENCES trabajador(id_usuario) ON DELETE SET NULL
);

CREATE TABLE cupo_entrega (
    id_cupo INT AUTO_INCREMENT PRIMARY KEY,
    fecha_entrega DATE NOT NULL,
    hora_inicio TIME NOT NULL,
    hora_fin TIME NOT NULL,
    capacidad INT NOT NULL DEFAULT 2,
    reservadas INT NOT NULL DEFAULT 0,
    CONSTRAINT chk_cupo_capacidad CHECK (capacidad > 0),
    CONSTRAINT chk_cupo_reservadas CHECK (reservadas >= 0 AND reservadas <= capacidad),
    CONSTRAINT uq_cupo_entrega_horario UNIQUE (fecha_entrega, hora_inicio, hora_fin)
);

CREATE TABLE programacion_entrega (
    id_programacion INT AUTO_INCREMENT PRIMARY KEY,
    id_solicitud INT NOT NULL UNIQUE,
    id_cupo INT NOT NULL,
    fecha_entrega DATE NOT NULL,
    hora_inicio TIME NOT NULL,
    hora_fin TIME NOT NULL,
    fecha_limite_recojo DATETIME NOT NULL,
    estado_programacion VARCHAR(30) NOT NULL DEFAULT 'PROGRAMADA',
    motivo_cancelacion TEXT,
    observacion TEXT,
    CONSTRAINT chk_programacion_estado CHECK (estado_programacion IN ('PROGRAMADA', 'NO_ASISTIO', 'COMPLETADA', 'CANCELADA')),
    FOREIGN KEY (id_solicitud) REFERENCES solicitud(id_solicitud) ON DELETE CASCADE,
    FOREIGN KEY (id_cupo) REFERENCES cupo_entrega(id_cupo)
);

CREATE INDEX idx_usuario_username ON usuario(username);
CREATE INDEX idx_usuario_rol ON usuario(rol);
CREATE INDEX idx_mascota_estado ON mascota(estado_adopcion);
CREATE UNIQUE INDEX uq_mascota_identidad_estado ON mascota(nombre, especie, raza, estado_adopcion);
CREATE INDEX idx_solicitud_estado ON solicitud(estado_solicitud);
CREATE INDEX idx_solicitud_adoptante ON solicitud(id_adoptante);
CREATE INDEX idx_solicitud_mascota ON solicitud(id_mascota);
CREATE INDEX idx_solicitud_trabajador ON solicitud(id_trabajador);
CREATE INDEX idx_programacion_estado ON programacion_entrega(estado_programacion);
CREATE INDEX idx_programacion_fecha ON programacion_entrega(fecha_entrega, hora_inicio, hora_fin);

-- LIMPIAR TABLAS PARA EVITAR CONFLICTOS DE LLAVES PRIMARIAS
SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE programacion_entrega;
TRUNCATE TABLE cupo_entrega;
TRUNCATE TABLE solicitud;
TRUNCATE TABLE mascota;
TRUNCATE TABLE adoptante;
TRUNCATE TABLE trabajador;
TRUNCATE TABLE usuario;
SET FOREIGN_KEY_CHECKS = 1;

-- =========================================================================
-- 1. TABLA: usuario (35 Usuarios en total para soportar la integridad)
-- =========================================================================
-- Id 1 al 15: Trabajadores y Admins | Id 16 al 35: Adoptantes
-- Contraseña de prueba para todos: '123'
INSERT INTO usuario (id_usuario, username, password, rol, activo) VALUES
(1, 'admin', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_ADMIN', TRUE),
(2, 'pepe', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_TRABAJADOR', TRUE),
(3, 'carlos_trab', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_TRABAJADOR', TRUE),
(4, 'maria_trab', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_TRABAJADOR', TRUE),
(5, 'luis_trab', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_TRABAJADOR', TRUE),
(6, 'ana_trab', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_TRABAJADOR', TRUE),
(7, 'jorge_trab', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_TRABAJADOR', TRUE),
(8, 'sofia_trab', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_TRABAJADOR', TRUE),
(9, 'pedro_trab', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_TRABAJADOR', TRUE),
(10, 'lucia_trab', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_TRABAJADOR', TRUE),
(11, 'marta_trab', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_TRABAJADOR', TRUE),
(12, 'roberto_trab', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_TRABAJADOR', TRUE),
(13, 'elena_trab', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_TRABAJADOR', TRUE),
(14, 'diego_trab', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_TRABAJADOR', TRUE),
(15, 'isabel_trab', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_TRABAJADOR', FALSE), -- Trabajador Inactivo
(16, 'rodrigo', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_ADOPTANTE', TRUE),
(17, 'ana', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_ADOPTANTE', TRUE),
(18, 'jose', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_ADOPTANTE', TRUE),
(19, 'beatriz_adop', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_ADOPTANTE', TRUE),
(20, 'marcos_adop', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_ADOPTANTE', TRUE),
(21, 'gabriela_adop', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_ADOPTANTE', TRUE),
(22, 'javier_adop', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_ADOPTANTE', TRUE),
(23, 'valeria_adop', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_ADOPTANTE', TRUE),
(24, 'tomas_adop', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_ADOPTANTE', TRUE),
(25, 'camila_adop', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_ADOPTANTE', TRUE),
(26, 'alejandro_adop', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_ADOPTANTE', TRUE),
(27, 'natalia_adop', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_ADOPTANTE', TRUE),
(28, 'daniel_adop', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_ADOPTANTE', TRUE),
(29, 'claudia_adop', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_ADOPTANTE', TRUE),
(30, 'ricardo_adop', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_ADOPTANTE', TRUE),
(31, 'vanessa_adop', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_ADOPTANTE', TRUE),
(32, 'fernando_adop', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_ADOPTANTE', TRUE),
(33, 'monica_adop', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_ADOPTANTE', TRUE),
(34, 'esteban_adop', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_ADOPTANTE', TRUE),
(35, 'laura_adop', '$2a$12$sF84YBQQDkPrtIYv8rjr5.eBr41yq2hPSKvbn490SOBMCtagHegNe', 'ROLE_ADOPTANTE', TRUE);

-- =========================================================================
-- 2. TABLA: trabajador (Total: 15)
-- =========================================================================
INSERT INTO trabajador (id_usuario, nom_trabajador, ape_trabajador, dni, fec_nacimiento, email, telefono) VALUES
(1, 'Admin', 'General', '11111111', '1990-01-01', 'admin@pet.com', '999888777'),
(2, 'Pepe', 'Lucho', '22222222', '1995-05-15', 'pepe@pet.com', '999111222'),
(3, 'Carlos', 'Mendoza', '10203040', '1988-04-12', 'carlos@pet.com', '945612347'),
(4, 'Maria', 'Delgado', '20304050', '1993-09-22', 'maria@pet.com', '912345671'),
(5, 'Luis', 'Soto', '30405060', '1991-02-28', 'luis@pet.com', '923456782'),
(6, 'Ana', 'Benitez', '40506070', '1996-07-19', 'ana.t@pet.com', '934567893'),
(7, 'Jorge', 'Guerra', '50607080', '1985-11-05', 'jorge@pet.com', '945678904'),
(8, 'Sofia', 'Ruiz', '60708090', '1994-03-14', 'sofia@pet.com', '956789015'),
(9, 'Pedro', 'Infante', '70809001', '1992-06-25', 'pedro@pet.com', '967890126'),
(10, 'Lucia', 'Caceres', '80900102', '1997-12-01', 'lucia@pet.com', '978901237'),
(11, 'Marta', 'Vidal', '90010203', '1989-10-10', 'marta@pet.com', '989012348'),
(12, 'Roberto', 'Gomez', '01020304', '1990-08-17', 'roberto@pet.com', '990123459'),
(13, 'Elena', 'Paz', '12131415', '1995-01-30', 'elena@pet.com', '911234560'),
(14, 'Diego', 'Torres', '16171819', '1993-05-14', 'diego@pet.com', '922345671'),
(15, 'Isabel', 'Luna', '21222324', '1996-02-11', 'isabel@pet.com', '933456782');

-- =========================================================================
-- 3. TABLA: adoptante (Total: 20)
-- =========================================================================
INSERT INTO adoptante (id_usuario, nom_adoptante, ape_adoptante, fec_nacimiento, dni, email, telefono, direccion) VALUES
(16, 'Rodrigo', 'Leon', '2000-10-10', '33333333', 'rodrigo@mail.com', '987654321', 'Av. Lima 123, Miraflores'),
(17, 'Ana', 'Garcia', '1998-03-25', '44444444', 'ana@mail.com', '912345678', 'Calle Las Flores 456, Surco'),
(18, 'Jose', 'Martinez', '1995-07-12', '55555555', 'jose@mail.com', '987123456', 'Jr. Los Alamos 789, Los Olivos'),
(19, 'Beatriz', 'Cueva', '1992-11-23', '66666666', 'beatriz@mail.com', '991223344', 'Av. Larco 880, Miraflores'),
(20, 'Marcos', 'Polo', '1994-05-05', '77777777', 'marcos@mail.com', '944556677', 'Calle Tarapacá 123, Magdalena'),
(21, 'Gabriela', 'Ramos', '1997-08-14', '88888888', 'gabriela@mail.com', '922334455', 'Av. Universitaria 1450, San Miguel'),
(22, 'Javier', 'Salas', '1991-01-15', '99999999', 'javier@mail.com', '955667788', 'Jr. Junín 432, Cercado de Lima'),
(23, 'Valeria', 'Vega', '1999-09-09', '11223344', 'valeria@mail.com', '966778899', 'Av. Arequipa 3200, San Isidro'),
(24, 'Tomas', 'Díaz', '1993-04-03', '22334455', 'tomas@mail.com', '977889900', 'Calle Tulipanes 211, Lince'),
(25, 'Camila', 'Silva', '1996-12-25', '33445566', 'camila@mail.com', '988990011', 'Av. Brasil 2300, Jesús María'),
(26, 'Alejandro', 'Cruz', '1990-06-18', '44556677', 'alejandro@mail.com', '999001122', 'Jr. Huallaga 567, Cercado'),
(27, 'Natalia', 'Peña', '1998-02-20', '55667788', 'natalia@mail.com', '911992233', 'Av. Javier Prado 1500, San Borja'),
(28, 'Daniel', 'Flores', '1994-10-31', '66778899', 'daniel@mail.com', '922883344', 'Calle San Martín 765, Barranco'),
(29, 'Claudia', 'Arias', '1995-03-14', '77889900', 'claudia@mail.com', '933774455', 'Jr. Cuzco 321, Chorrillos'),
(30, 'Ricardo', 'Bazan', '1989-07-22', '88990011', 'ricardo@mail.com', '944665566', 'Av. Reducto 450, Miraflores'),
(31, 'Vanessa', 'Tello', '1997-05-17', '99001122', 'vanessa@mail.com', '955446677', 'Calle Los Pinos 123, San Isidro'),
(32, 'Fernando', 'Rojas', '1992-08-08', '12345672', 'fernando@mail.com', '966337788', 'Av. La Marina 2900, San Miguel'),
(33, 'Monica', 'Vargas', '1996-01-04', '23456783', 'monica@mail.com', '977228899', 'Jr. Carabaya 890, Lima'),
(34, 'Esteban', 'Gomez', '1991-03-19', '34567894', 'esteban@mail.com', '988112233', 'Av. Aviación 4500, Surco'),
(35, 'Laura', 'Mendez', '1993-11-12', '45678905', 'laura@mail.com', '999223344', 'Calle Las Magnolias 123, San Borja');

-- =========================================================================
-- 4. TABLA: mascota (Total: 22 registros con diversidad total de estados)
-- =========================================================================
INSERT INTO mascota (id_mascota, nombre, especie, raza, sexo, edad_anios, edad_meses, estado_salud, estado_adopcion, estado_esterilizacion, observaciones) VALUES
-- Históricas (Ya adoptadas o inactivas)
(1, 'Firulais', 'Perro', 'Labrador', 'MACHO', 2, 5, 'SIN NOVEDADES', 'ADOPTADO', 'ESTERILIZADO', 'Adopcion finalizada. Sociable y con vacunas al dia.'),
(2, 'Michi', 'Gato', 'Persa', 'MACHO', 1, 0, 'SIN NOVEDADES', 'ADOPTADO', 'ESTERILIZADO', 'Adopcion finalizada. Adaptado a departamento.'),
(3, 'Rambo', 'Perro', 'Pastor Alemán', 'MACHO', 3, 2, 'SIN NOVEDADES', 'ADOPTADO', 'ESTERILIZADO', 'Adopcion finalizada. Requiere actividad diaria.'),
(4, 'Luna', 'Gato', 'Siamés', 'HEMBRA', 0, 8, 'SIN NOVEDADES', 'ADOPTADO', 'PENDIENTE', 'Adopcion finalizada. Esterilizacion pendiente por edad al momento del registro.'),
(5, 'Rocky', 'Perro', 'Golden Retriever', 'MACHO', 4, 1, 'SIN NOVEDADES', 'ADOPTADO', 'ESTERILIZADO', 'Adopcion finalizada. Temperamento tranquilo.'),
(6, 'Teo', 'Perro', 'Mestizo', 'MACHO', 6, 0, 'CRITICO', 'INACTIVO', 'NO APLICA', 'No disponible por condicion de salud critica.'), -- Mascota que ya no está disponible por salud

-- En Proceso Actual (Reservados esperando cita de recojo)
(7, 'Bella', 'Perro', 'Poodle', 'HEMBRA', 1, 6, 'SIN NOVEDADES', 'RESERVADO', 'ESTERILIZADO', 'Reservada para entrega. Convive bien con familias.'),
(8, 'Toby', 'Perro', 'Chihuahua', 'MACHO', 5, 0, 'SIN NOVEDADES', 'RESERVADO', 'ESTERILIZADO', 'Reservado para entrega. Ideal para espacios pequenos.'),
(9, 'Coco', 'Gato', 'Angora', 'MACHO', 2, 3, 'SIN NOVEDADES', 'RESERVADO', 'ESTERILIZADO', 'Reservado para entrega. Independiente y tranquilo.'),
(10, 'Simba', 'Gato', 'Mestizo', 'MACHO', 0, 6, 'SIN NOVEDADES', 'RESERVADO', 'PENDIENTE', 'Reservado para entrega. Esterilizacion pendiente por edad.'),
(11, 'Zeus', 'Perro', 'Rottweiler', 'MACHO', 2, 11, 'SIN NOVEDADES', 'RESERVADO', 'ESTERILIZADO', 'Reservado para entrega. Requiere familia con experiencia.'),
(12, 'Max', 'Perro', 'Boxer', 'MACHO', 3, 0, 'SIN NOVEDADES', 'RESERVADO', 'ESTERILIZADO', 'Reservado para entrega. Energetico y sociable.'),
(13, 'Mia', 'Gato', 'Bengala', 'HEMBRA', 1, 2, 'SIN NOVEDADES', 'RESERVADO', 'ESTERILIZADO', 'Reservada para entrega. Curiosa y activa.'),

-- Disponibles en el sistema (Para solicitudes nuevas o pendientes)
(14, 'Lucas', 'Perro', 'Beagle', 'MACHO', 2, 4, 'SIN NOVEDADES', 'DISPONIBLE', 'ESTERILIZADO', 'Disponible. Buen temperamento y activo.'),
(15, 'Nala', 'Gato', 'Mestizo', 'HEMBRA', 1, 7, 'SIN NOVEDADES', 'DISPONIBLE', 'ESTERILIZADO', 'Disponible. Tranquila y apta para departamento.'),
(16, 'Bruno', 'Perro', 'Pug', 'MACHO', 4, 9, 'SIN NOVEDADES', 'DISPONIBLE', 'ESTERILIZADO', 'Disponible. Requiere paseos cortos y constantes.'),
(17, 'Kira', 'Perro', 'Siberiano', 'HEMBRA', 1, 1, 'SIN NOVEDADES', 'DISPONIBLE', 'PENDIENTE', 'Disponible. Esterilizacion pendiente de programacion.'),
(18, 'Pelusa', 'Gato', 'Ragdoll', 'HEMBRA', 3, 5, 'SIN NOVEDADES', 'DISPONIBLE', 'ESTERILIZADO', 'Disponible. Muy sociable con adultos.'),
(19, 'Thor', 'Perro', 'Dálmata', 'MACHO', 2, 2, 'SIN NOVEDADES', 'DISPONIBLE', 'ESTERILIZADO', 'Disponible. Necesita espacio y actividad diaria.'),
(20, 'Gara', 'Gato', 'Sphynx', 'HEMBRA', 1, 1, 'SIN NOVEDADES', 'DISPONIBLE', 'PENDIENTE', 'Disponible. Requiere cuidado de piel y seguimiento.'),
(21, 'Nela', 'Gato', 'Siames', 'HEMBRA', 1, 1, 'CRITICO', 'DISPONIBLE', 'NO APLICA', 'No debe publicarse en app hasta superar condicion critica.'),
(22, 'Nina', 'Gato', 'Mestizo', 'HEMBRA', 1, 1, 'EN TRATAMIENTO', 'DISPONIBLE', 'PENDIENTE', 'En tratamiento veterinario. No apta para adopcion hasta alta medica.');

-- =========================================================================
-- 5. TABLA: solicitud (Total: 20 registros con diversidad total de estados)
-- Cada solicitud tiene asignada una mascota diferente
-- =========================================================================
INSERT INTO solicitud (id_solicitud, fecha_registro, id_adoptante, id_mascota, id_trabajador, comentario, motivo_adopcion, tipo_vivienda, experiencia_mascotas, otras_mascotas, cantidad_personas_hogar, estado_solicitud, motivo_rechazo) VALUES
-- PASADO: Solicitudes que terminaron con éxito (Finalizadas)
(1, '2026-04-10', 16, 1, 2, 'Adopción completada el mes pasado', 'Compañía', 'Casa', 'Sí', 'No', 4, 'FINALIZADA', NULL),
(2, '2026-04-12', 17, 2, 3, 'Todo perfecto con el felino', 'Afecto', 'Departamento', 'No', 'No', 2, 'FINALIZADA', NULL),
(3, '2026-04-15', 18, 3, 4, 'Proceso concluido sin novedades', 'Seguridad', 'Casa', 'Sí', 'No', 5, 'FINALIZADA', NULL),
(4, '2026-04-20', 19, 4, 2, 'Gatito adaptado al hogar', 'Compañía', 'Departamento', 'Sí', 'No', 1, 'FINALIZADA', NULL),
(5, '2026-04-25', 20, 5, 5, 'Firma de acta física realizada', 'Espacio', 'Casa', 'Sí', 'Sí', 6, 'FINALIZADA', NULL),

-- PASADO: Solicitudes rechazadas o canceladas por el usuario
(6, '2026-05-02', 21, 6, 3, 'Rechazado en la entrevista', 'Soporte emocional', 'Cuarto', 'No', 'Sí', 1, 'RECHAZADA', 'Vivienda no cuenta con espacio mínimo requerido.'),
(7, '2026-05-05', 22, 14, NULL, 'Usuario desistió del proceso', 'Mascota propia', 'Casa', 'Sí', 'No', 3, 'CANCELADA', NULL),
(8, '2026-05-10', 23, 15, 4, 'No se presentó a la cita programada', 'Compañía', 'Departamento', 'No', 'No', 2, 'NO_ASISTIO', 'Ausencia del adoptante en el bloque pautado.'),

-- FUTURO/PRESENTE: Solicitudes aprobadas esperando recojo (Mascotas Reservadas)
(9, '2026-05-28', 24, 7, 2, 'Cita agendada para el 15 de junio', 'Regalo familiar', 'Casa', 'Sí', 'No', 4, 'APROBADA', NULL),
(10, '2026-05-28', 25, 8, 3, 'Aprobada, coordinando horarios', 'Compañía', 'Departamento', 'Sí', 'No', 2, 'APROBADA', NULL),
(11, '2026-05-29', 26, 9, 4, 'Cumple con el perfil de adoptante', 'Afecto', 'Casa', 'No', 'No', 3, 'APROBADA', NULL),
(12, '2026-05-29', 27, 10, 5, 'Acepta condiciones de tratamiento', 'Ayuda social', 'Departamento', 'Sí', 'No', 4, 'APROBADA', NULL),
(13, '2026-05-30', 28, 11, 2, 'Verificación domiciliaria exitosa', 'Compañía', 'Casa', 'Sí', 'Sí', 5, 'APROBADA', NULL),
(14, '2026-05-30', 29, 12, 6, 'Todo en regla con los documentos', 'Pasión por la raza', 'Departamento', 'Sí', 'No', 2, 'APROBADA', NULL),
(15, '2026-05-31', 30, 13, 7, 'Último aprobado de la semana', 'Hogar activo', 'Casa', 'Sí', 'No', 3, 'APROBADA', NULL),

-- PRESENTE: Solicitudes nuevas esperando evaluación del panel de trabajador (Mascotas Disponibles)
(16, '2026-06-01', 31, 16, NULL, 'Evaluación de ficha pendiente', 'Compañía', 'Departamento', 'No', 'No', 2, 'PENDIENTE', NULL),
(17, '2026-06-01', 32, 17, NULL, 'Revisar antecedentes penales', 'Compañía', 'Casa', 'Sí', 'No', 4, 'PENDIENTE', NULL),
(18, '2026-06-02', 33, 18, NULL, 'En espera de asignar trabajador', 'Afecto', 'Departamento', 'Sí', 'Sí', 1, 'PENDIENTE', NULL),
(19, '2026-06-02', 34, 19, NULL, 'Postulante con patio amplio', 'Espacio', 'Casa', 'Sí', 'No', 5, 'PENDIENTE', NULL),
(20, '2026-06-02', 35, 20, NULL, 'Solicitud ingresada por la web', 'Ayuda', 'Departamento', 'No', 'No', 2, 'PENDIENTE', NULL);

-- =========================================================================
-- 6. TABLA: cupo_entrega (Total: 15)
-- Bloques fijos: 10:00 a 12:00, 14:00 a 16:00, 16:00 a 18:00
-- =========================================================================
INSERT INTO cupo_entrega (id_cupo, fecha_entrega, hora_inicio, hora_fin, capacidad, reservadas) VALUES
-- PASADO: Cupos históricos (Mayo 2026)
(1, '2026-05-10', '10:00:00', '12:00:00', 2, 2),
(2, '2026-05-10', '14:00:00', '16:00:00', 2, 1),
(3, '2026-05-15', '16:00:00', '18:00:00', 2, 2),

-- FUTURO: Cupos de gestión entrantes (Julio 2026)
-- Día 15 de Julio: Llenos (Capacidad máxima 2 de 2 para probar bloqueos en UI)
(4, '2026-07-15', '10:00:00', '12:00:00', 2, 2),
(5, '2026-07-15', '14:00:00', '16:00:00', 2, 2),
(6, '2026-07-15', '16:00:00', '18:00:00', 2, 2),

-- Día 16 de Julio: Con disponibilidad parcial o vacíos para simular reservas nuevas
(7, '2026-07-16', '10:00:00', '12:00:00', 2, 1), -- Solo 1 reservado
(8, '2026-07-16', '14:00:00', '16:00:00', 2, 0), -- Totalmente disponible
(9, '2026-07-16', '16:00:00', '18:00:00', 2, 0), -- Totalmente disponible

-- Cupos extra requeridos 
(10, '2026-07-17', '10:00:00', '12:00:00', 2, 0),
(11, '2026-07-17', '14:00:00', '16:00:00', 2, 0),
(12, '2026-07-17', '16:00:00', '18:00:00', 2, 0),
(13, '2026-07-18', '10:00:00', '12:00:00', 2, 0),
(14, '2026-07-18', '14:00:00', '16:00:00', 2, 0),
(15, '2026-07-18', '16:00:00', '18:00:00', 2, 0);

-- =========================================================================
-- 7. TABLA: programacion_entrega (Total: 15 registros con todos los estados)
-- =========================================================================
INSERT INTO programacion_entrega (id_programacion, id_solicitud, id_cupo, fecha_entrega, hora_inicio, hora_fin, fecha_limite_recojo, estado_programacion, motivo_cancelacion, observacion) VALUES
-- PASADO: Citas concluidas en Mayo (Estados: COMPLETADA, CANCELADA, NO_ASISTIO)
(1, 1, 1, '2026-05-10', '10:00:00', '12:00:00', '2026-05-10 12:00:00', 'COMPLETADA', NULL, 'Adoptante puntual. Se llevó el kit inicial.'),
(2, 2, 1, '2026-05-10', '10:00:00', '12:00:00', '2026-05-10 12:00:00', 'COMPLETADA', NULL, 'Trámite rápido. Firma conforme.'),
(3, 3, 2, '2026-05-10', '14:00:00', '16:00:00', '2026-05-10 16:00:00', 'CANCELADA', 'Calamidad doméstica reportada', 'Llamó a cancelar 2 horas antes.'),
(4, 4, 3, '2026-05-15', '16:00:00', '18:00:00', '2026-05-15 18:00:00', 'COMPLETADA', NULL, 'Gato en transportadora del adoptante.'),
(5, 5, 3, '2026-05-15', '16:00:00', '18:00:00', '2026-05-15 18:00:00', 'COMPLETADA', NULL, 'Faltaba foto del DNI físico, se escaneó en oficina.'),
(6, 8, 2, '2026-05-10', '14:00:00', '16:00:00', '2026-05-10 16:00:00', 'NO_ASISTIO', NULL, 'Se le llamó y tenía el celular apagado.'),

-- FUTURO: Citas agendadas e intocables del 15 de Julio (Saturan los cupos 4, 5 y 6)
(7, 9, 4, '2026-07-15', '10:00:00', '12:00:00', '2026-07-15 12:00:00', 'PROGRAMADA', NULL, 'Pendiente traer documento.'),
(8, 10, 4, '2026-07-15', '10:00:00', '12:00:00', '2026-07-15 12:00:00', 'PROGRAMADA', NULL, 'Requiere asistencia en parqueadero.'),
(9, 11, 5, '2026-07-15', '14:00:00', '16:00:00', '2026-07-15 16:00:00', 'PROGRAMADA', NULL, 'Llamar antes para confirmar ruta.'),
(10, 12, 5, '2026-07-15', '14:00:00', '16:00:00', '2026-07-15 16:00:00', 'PROGRAMADA', NULL, NULL),
(11, 13, 6, '2026-07-15', '16:00:00', '18:00:00', '2026-07-15 18:00:00', 'PROGRAMADA', NULL, NULL),
(12, 14, 6, '2026-07-15', '16:00:00', '18:00:00', '2026-07-15 18:00:00', 'PROGRAMADA', NULL, 'Viene con dos acompañantes.'),

-- FUTURO: Citas del 16 de Julio (Ocupa parcialmente el cupo 7)
(13, 15, 7, '2026-07-16', '10:00:00', '12:00:00', '2026-07-16 12:00:00', 'PROGRAMADA', NULL, NULL),

-- SOLUCIÓN A REGISTROS EXTRAS (14 y 15) 
(14, 6, 1, '2026-05-10', '10:00:00', '12:00:00', '2026-05-10 12:00:00', 'CANCELADA', 'Rechazo previo de la solicitud', 'Se canceló automáticamente al denegar la solicitud.'),
(15, 7, 2, '2026-05-10', '14:00:00', '16:00:00', '2026-05-10 16:00:00', 'CANCELADA', 'El adoptante canceló', 'Se canceló automáticamente al denegar la solicitud.');

-- =========================================================================
-- CASO DE PRUEBA: FINALIZAR POR CONTINGENCIA
-- Solicitud 15 queda APROBADA, con cita vencida, acta generada y acta firmada
-- registrada. Ingresar como admin y abrir /solicitudes/detalle/15.
-- =========================================================================
UPDATE cupo_entrega
SET fecha_entrega = '2026-06-02',
    hora_inicio = '10:00:00',
    hora_fin = '12:00:00'
WHERE id_cupo = 7;

UPDATE programacion_entrega
SET fecha_entrega = '2026-06-02',
    hora_inicio = '10:00:00',
    hora_fin = '12:00:00',
    fecha_limite_recojo = '2026-06-02 12:30:00',
    observacion = 'Caso de prueba para cierre por contingencia.'
WHERE id_programacion = 13;

UPDATE solicitud
SET ruta_pdf_acta = 'documentos/acta_adopcion_15.pdf',
    ruta_acta_firmada = NULL
WHERE id_solicitud = 15;
